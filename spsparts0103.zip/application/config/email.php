<?php

$config['useragent'] = 'CodeIgniter';
$config['protocol'] = 'smtp';
$config['mailpath'] = '/usr/sbin/sendmail';
$config['smtp_host'] = 'mail.suryamoto.com';
$config['smtp_user'] = 'admin@suryamoto.com';
$config['smtp_pass'] = 'Bismillah#123';
$config['smtp_port'] = 465;
$config['smtp_keepalive'] = TRUE;
$config['smtp_timeout'] = 50;
$config['wordwrap'] = TRUE;
$config['wrapchars'] = 80;
$config['mailtype'] = 'html';
$config['smtp_crypto']= 'ssl';
$config['charset']  = 'iso-8859-1';
$config['validate']  = TRUE;
$config['crlf']  = "\r\n";
$config['newline'] = "\r\n";

?>
