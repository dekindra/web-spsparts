
        <div class="row">
          <div class="col-md-4">
            <a href="<?php echo base_url(); ?>bengkel/add" class="span3" style="">
              <div class="panell">
                <div class="panel-body">
                  <div class="card-box">
                    <div class="text-center box sekolah">
                      <p><img src="https://png.icons8.com/color/100/000000/small-business.png"></p>
                        <h4>Bengkel</h4>
                      <p>Pendaftaran Bengkel Mitra PT.SPS Indonesia</p>
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class="col-md-4">
            <a href="<?php echo base_url(); ?>gudang/add" class="span3" style="">
              <div class="panell">
                <div class="panel-body">
                  <div class="card-box">
                    <div class="text-center box sekolah">
                      <p><img src="https://png.icons8.com/color/100/000000/garage-closed.png"></p>
                        <h4>Gudang</h4>
                      <p>Pendaftaran Gudang Mitra PT.SPS Indonesia</p>
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class="col-md-4">
            <a href="<?php echo base_url(); ?>supplier/add" class="span3" style="">
              <div class="panell">
                <div class="panel-body">
                  <div class="card-box">
                    <div class="text-center box sekolah">
                      <p><img src="https://png.icons8.com/color/100/000000/supplier.png"></p>
                        <h4>Supplier</h4>
                      <p>Pendaftaran Supplier Mitra PT.SPS Indonesia</p>
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>

   