      <div class="page-content container-fluid">
        <!-- <div class="row">
          <div class="col-lg-3"> -->
            <!-- Page Widget -->
            <!-- <div class="card card-shadow text-center">
              <div class="card-block">
                <a class="avatar avatar-lg" href="javascript:void(0)">
                  <img src="<?php echo base_url(); ?>assets/global/portraits/5.jpg" alt="...">
                </a>
                <h4 class="profile-user">ricoagung@gmail.com</h4>
                <p class="profile-job">Admin</p>
                <p>Hi! I'm ricoagung the Admin of SPS Parts.</p> -->
                <!-- <div class="profile-social">
                  <a class="icon bd-twitter" href="javascript:void(0)"></a>
                  <a class="icon bd-facebook" href="javascript:void(0)"></a>
                  <a class="icon bd-dribbble" href="javascript:void(0)"></a>
                  <a class="icon bd-github" href="javascript:void(0)"></a>
                </div> -->
                <!-- <button type="button" class="btn btn-primary">Follow</button> -->
              <!-- </div> -->
             <!--  <div class="card-footer">
                <div class="row no-space">
                  <div class="col-4">
                    <strong class="profile-stat-count">260</strong>
                    <span>Follower</span>
                  </div>
                  <div class="col-4">
                    <strong class="profile-stat-count">180</strong>
                    <span>Following</span>
                  </div>
                  <div class="col-4">
                    <strong class="profile-stat-count">2000</strong>
                    <span>Tweets</span>
                  </div>
                </div>
              </div> -->
            <!-- </div> -->
            <!-- End Page Widget -->
          <!-- </div> -->

          <!-- <div class="col-lg-9"> -->
            <!-- Panel -->
            <!-- <div class="panel">
              <div class="panel-body"> -->
                <!-- <form autocomplete="off">
                  <div class="form-group form-material floating" data-plugin="formMaterial">
                    <input type="text" class="form-control" name="nama" data-hint="Masukkan nama lengkap anda"/>
                    <label class="floating-label">Nama</label>
                  </div>
                  <div class="form-group form-material floating" data-plugin="formMaterial">
                    <input type="email" class="form-control" name="kode" data-hint="Masuk dengan e-mail ini."/>
                    <label class="floating-label">E-mail</label>
                  </div>
                  <div class="form-group form-material floating" data-plugin="formMaterial">
                    <label class="form-control-label" for="inputPassword2">Password</label>
                    <input type="password" class="form-control" id="inputPassword2" name="inputPasswords" data-plugin="strength" data-show-toggle="true" value="" />
                    <br>
                  </div>
                  <div class="form-group form-material floating" data-plugin="formMaterial">
                        <input type="text" class="form-control" readonly="" />
                        <input type="file" name="inputFloatingFile" multiple="" />
                        <label class="floating-label">Foto..</label>
                  </div>
                  <button type="button" class="btn btn-primary" style="float: right;">Update</button>
                </form> -->
                <!-- <form autocomplete="off"> -->
                      <!-- <div class="form-group">
                        <label class="form-control-label" for="inputCardNumber">Card Number</label>
                        <input type="text" class="form-control" id="inputCardNumber" name="nomer" placeholder="Card number">
                      </div>
                      <div class="form-group">
                        <label class="form-control-label" for="inputCVV">CVV</label>
                        <input type="text" class="form-control" id="" name="cvv" placeholder="CVV">
                      </div> -->
                      <!-- <div class="form-group form-material floating" data-plugin="formMaterial">
                        <input type="text" class="form-control" name="number"/>
                        <label class="floating-label">Nama Gudang</label>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" name="number"/>
                            <label class="floating-label">Instansi</label>
                          </div>
                        </div>
                         <div class="col-md-6">
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" name="number"/>
                            <label class="floating-label">Telepon Instansi</label>
                          </div>
                        </div>
                      </div>
                      <div class="form-group form-material floating" data-plugin="formMaterial">
                        <input type="text" class="form-control" name="number"/>
                        <label class="floating-label">Alamat</label>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" name="number"/>
                            <label class="floating-label">Penanggung Jawab</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" name="number"/>
                            <label class="floating-label">Telepon Penanggung Jawab</label>
                          </div>
                        </div>
                      </div>
                      <div class="form-group form-material floating" data-plugin="formMaterial">
                        <input type="email" class="form-control" name="number"/>
                        <label class="floating-label">Email Penanggung Jawab</label>
                      </div>
                      <div class="form-group form-material floating" data-plugin="formMaterial">
                        <label class="form-control-label" for="inputPassword2">Password</label>
                        <input type="password" class="form-control" id="inputPassword2" name="password" data-plugin="strength" data-show-toggle="true" value="" />
                        <br><br>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" readonly="" />
                            <input type="file" name="inputFloatingFile" multiple="" />
                            <label class="floating-label">KTP Penanggung Jawab..</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" readonly="" />
                            <input type="file" name="inputFloatingFile" multiple="" />
                            <label class="floating-label">Rencana Gudang..</label>
                          </div>
                        </div>
                      </div>
                      <button type="button" class="btn btn-primary" style="float: right;">Update</button>
                    </form>
                    
              </div>
            </div> -->
            <!-- End Panel -->
                        <!-- Panel -->
            <div class="panel">
              <?php
              $alert_msg = $this->session->flashdata('alert_msg');
                  if (!empty($alert_msg)) {
                    $flash_status = $alert_msg[0];
                    $flash_header = $alert_msg[1];
                    $flash_desc = $alert_msg[2];

                    if ($flash_status == 'failure') {
                ?>
                    <div class="alert alert-alt alert-danger alert-dismissible" style="text-align: left;" role="alert">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                      <?php echo $flash_header; ?><br><a class="alert-link" style="margin-left: 0" href="javascript:void(0)"><?php echo $flash_desc; ?></a>
                    </div>
                <?php 
                    }
                    if ($flash_status == 'success') {
                ?>
                    <div class="alert alert-alt alert-success alert-dismissible" role="alert">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                      <?php echo $flash_header; ?>, <a class="alert-link" style="margin-left: 0" href="javascript:void(0)"><?php echo $flash_desc; ?></a>
                    </div>
                <?php
                    }
                  }
                ?>
              <div class="panel-body nav-tabs-animate nav-tabs-horizontal" data-plugin="tabs">
                <ul class="nav nav-tabs nav-tabs-line" role="tablist">
                  <li class="nav-item" role="presentation"><a class="active nav-link" data-toggle="tab" href="#activities"
                      aria-controls="activities" role="tab">Umum</a></li>
                  <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#profile" aria-controls="profile"
                      role="tab">Akun</a></li>
                  <li class="nav-item dropdown">
                    <a class="dropdown-toggle nav-link" data-toggle="dropdown" href="#" aria-expanded="false">Menu </a>
                    <div class="dropdown-menu" role="menu">
                      <a class="active dropdown-item" data-toggle="tab" href="#activities" aria-controls="activities"
                        role="tab">Umum</a>
                      <a class="dropdown-item" data-toggle="tab" href="#profile" aria-controls="profile"
                        role="tab">Akun</a>
                    </div>
                  </li>
                </ul>

                <div class="tab-content">
                  <div class="tab-pane active animation-slide-left" id="activities" role="tabpanel">
                    <form autocomplete="off" id="form">
                      <!-- <div class="form-group">
                        <label class="form-control-label" for="inputCardNumber">Card Number</label>
                        <input type="text" class="form-control" id="inputCardNumber" name="nomer" placeholder="Card number">
                      </div>
                      <div class="form-group">
                        <label class="form-control-label" for="inputCVV">CVV</label>
                        <input type="text" class="form-control" id="" name="cvv" placeholder="CVV">
                      </div> -->
                      <?php if($this->session->userdata('type') == 'gudang'): ?>
                        <input type="hidden" name="id" value="<?php echo $profils -> id_gudang ?>">
                      <?php else: ?>
                        <input type="hidden" name="id" value="<?php echo $profils -> id_bengkel ?>">
                      <?php endif ?>
                      <div class="form-group form-material floating" data-plugin="formMaterial">
                        <input type="text" class="form-control" name="nama" value="<?php echo $profils -> name ?>" />
                        <label class="floating-label">Nama</label>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" name="instansi" value="<?php echo $profils -> instansi ?>"/>
                            <label class="floating-label">Instansi</label>
                          </div>
                        </div>
                         <div class="col-md-6">
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" name="telepon" value="<?php echo $profils -> tel ?>"/>
                            <label class="floating-label">Telepon Instansi</label>
                          </div>
                        </div>
                      </div>
                      <div class="form-group form-material floating" data-plugin="formMaterial">
                        <input type="text" class="form-control" name="alamat" value="<?php echo $profils -> address ?>"/>
                        <label class="floating-label">Alamat</label>
                      </div>
                      <?php if ($this->session->userdata('type') == 'gudang'):?>
                        <div class="form-group form-material floating" data-plugin="formMaterial">
                          <input type="text" class="form-control" name="area" value="<?php echo $profils -> area ?>"/>
                          <label class="floating-label">Area</label>
                        </div>
                      <?php else: ?>
                        <?php if(is_null($statusgudang)): ?>
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <select class="form-control" name="gudang">
                              <?php foreach ($gudangs as $gdg) { ?>

                               <!-- CARA BIASA
                                <option value="<?php echo $gdg->id_gudang; ?>" <?php if($gdg->id_gudang == $profils->wh):?> selected="selected"<?php endif; ?>><?php echo $gdg->name; ?> | <?php echo $gdg->area; ?></option> -->
                                <!-- CARA TERNARY-->
                                <option value="<?php echo $gdg->id_gudang; ?>" <?php echo ($gdg->id_gudang == $profils->wh) ? 'selected' : ''; ?>><?php echo $gdg->name; ?> | <?php echo $gdg->area; ?></option>
                              <?php } ?>
                            </select>
                            <label class="floating-label">Gudang</label>
                          </div>
                          <?php else: ?>
                            <?php if($statusgudang->status == 0): ?>
                              <div class="form-group form-material floating" data-plugin="formMaterial">
                                <select class="form-control" name="gudang">
                                  <?php foreach ($gudangs as $gdg) { ?>
                                    <option value="<?php echo $gdg->id_gudang; ?>" <?php echo ($gdg->id_gudang == $profils->wh) ? 'selected' : ''; ?>><?php echo $gdg->name; ?> | <?php echo $gdg->area; ?></option>
                                  <?php } ?>
                                </select>
                                <label class="floating-label">Gudang</label>
                              </div>
                              <?php else: ?>
                                <div class="form-group form-material floating" data-plugin="formMaterial">
                                  <select class="form-control" name="gudang" disabled="disabled">
                                    <?php foreach ($gudangs as $gdg) { ?>
                                      <option value="<?php echo $gdg->id_gudang; ?>" <?php echo ($gdg->id_gudang == $profils->wh) ? 'selected' : ''; ?>><?php echo $gdg->name; ?> | <?php echo $gdg->area; ?></option>
                                    <?php } ?>
                                  </select>
                                  <label class="floating-label">Gudang</label>
                                </div>
                            <?php endif ?>
                        <?php endif ?>
                      <?php endif ?>
                     <!--  <div class="row">
                        <div class="col-md-6">
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" name="number"/>
                            <label class="floating-label">Penanggung Jawab</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" name="number"/>
                            <label class="floating-label">Telepon Penanggung Jawab</label>
                          </div>
                        </div>
                      </div>
                      <div class="form-group form-material floating" data-plugin="formMaterial">
                        <input type="email" class="form-control" name="number"/>
                        <label class="floating-label">Email Penanggung Jawab</label>
                      </div>
                      <div class="form-group form-material floating" data-plugin="formMaterial">
                        <label class="form-control-label" for="inputPassword2">Password</label>
                        <input type="password" class="form-control" id="inputPassword2" name="password" data-plugin="strength" data-show-toggle="true" value="" />
                        <br><br>
                      </div> -->
                      <div class="form-group form-material floating" data-plugin="formMaterial">
                        <input type="text" class="form-control" name="telpj" value="<?php echo $profils -> telpj ?>"/>
                        <label class="floating-label">Telepon Penanggung Jawab</label>
                      </div>

                    <div class="row">
                    <?php if($this->session->userdata('type') == 'gudang'): ?>
                      <?php if ($profils -> ktp): ?>
                        <div class="col-md-6">
                          <div class="" id="photo-preview">
                            <label>Photo</label>
                            <div class="col-md-12">
                                <img src="<?php echo base_url(); ?>assets/images/gudang/<?php echo $profils -> ktp ?>" class="img-responsive" style="width: 160px">
                              <span class="help-block"></span>
                            </div>
                          </div>
                        <br><input type="checkbox" name="remove_photo" value="<?php echo $profils -> ktp ?>"/> Remove photo when saving<br>
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" readonly="" />
                            <input type="file" name="ktp" multiple="" />
                            <label class="floating-label">Change KTP..</label>
                          </div>
                        </div>
                      <?php else: ?>
                        <div class="col-md-6">
                          <div class="" id="photo-preview">
                          <label>Photo</label>
                            <div class="col-md-12">
                              (No photo)
                              <span class="help-block"></span>
                            </div>
                          </div>
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                                <input type="text" class="form-control" readonly="" />
                                <input type="file" name="ktp" multiple="" />
                                <label class="floating-label">Upload KTP..</label>
                          </div>
                        </div>
                      <?php endif ?>
                    <?php else: ?>
                      <?php if ($profils -> ktp): ?>
                        <div class="col-md-6">
                          <div class="" id="photo-preview">
                            <label>Photo</label>
                            <div class="col-md-12">
                                <img src="<?php echo base_url(); ?>assets/images/bengkel/<?php echo $profils -> ktp ?>" class="img-responsive" style="width: 160px">
                              <span class="help-block"></span>
                            </div>
                          </div>
                          <br><input type="checkbox" name="remove_photo" value="<?php echo $profils -> ktp ?>"/> Remove photo when saving<br>
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" readonly="" />
                            <input type="file" name="ktp" multiple="" />
                            <label class="floating-label">Change KTP..</label>
                          </div>
                        </div>
                      <?php else: ?>
                        <div class="col-md-6">
                          <div class="" id="photo-preview">
                          <label>Photo</label>
                            <div class="col-md-12">
                              (No photo)
                              <span class="help-block"></span>
                            </div>
                          </div>
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                                <input type="text" class="form-control" readonly="" />
                                <input type="file" name="ktp" multiple="" />
                                <label class="floating-label">Upload KTP..</label>
                          </div>
                        </div>
                      <?php endif ?>
                    <?php endif ?>
                      <?php if ($this->session->userdata('type') == 'gudang'): ?>
                        <?php if ($profils -> wh): ?>
                          <div class="col-md-6">
                            <div class="" id="photo-preview1">
                            <label>Photo</label>
                              <div class="col-md-12">
                                <img src="<?php echo base_url(); ?>assets/images/gudang/<?php echo $profils -> wh ?>" class="img-responsive" style="width: 160px">
                                <span class="help-block"></span>
                              </div>
                            </div>
                            <br><input type="checkbox" name="remove_photo1" value="<?php echo $profils -> wh ?>"/> Remove photo when saving<br>
                            <div class="form-group form-material floating" data-plugin="formMaterial">
                              <input type="text" class="form-control" readonly="" />
                              <input type="file" name="rencana" multiple="" />
                              <label class="floating-label">Change Photo Rencana..</label>
                            </div>
                          </div>
                        <?php else: ?>
                          <div class="col-md-6">
                            <div class="" id="photo-preview1">
                            <label>Photo</label>
                              <div class="col-md-12">
                                (No photo)
                                <span class="help-block"></span>
                              </div>
                            </div>
                            <div class="form-group form-material floating" data-plugin="formMaterial">
                                  <input type="text" class="form-control" readonly="" />
                                  <input type="file" name="rencana" multiple="" />
                                  <label class="floating-label">Upload Photo Rencana..</label>
                            </div>
                          </div>
                        <?php endif ?>
                      <?php else: ?>
                        <?php if ($profils -> ws): ?>
                          <div class="col-md-6">
                            <div class="" id="photo-preview1">
                            <label>Photo</label>
                              <div class="col-md-12">
                                <img src="<?php echo base_url(); ?>assets/images/bengkel/<?php echo $profils -> ws ?>" class="img-responsive" style="width: 160px">
                                <span class="help-block"></span>
                              </div>
                            </div>
                            <br><input type="checkbox" name="remove_photo1" value="<?php echo $profils -> ws ?>"/> Remove photo when saving<br>
                            <div class="form-group form-material floating" data-plugin="formMaterial">
                              <input type="text" class="form-control" readonly="" />
                              <input type="file" name="rencana" multiple="" />
                              <label class="floating-label">Change Photo Rencana..</label>
                            </div>
                          </div>
                        <?php else: ?>
                          <div class="col-md-6">
                            <div class="" id="photo-preview1">
                            <label>Photo</label>
                              <div class="col-md-12">
                                (No photo)
                                <span class="help-block"></span>
                              </div>
                            </div>
                            <div class="form-group form-material floating" data-plugin="formMaterial">
                                  <input type="text" class="form-control" readonly="" />
                                  <input type="file" name="rencana" multiple="" />
                                  <label class="floating-label">Upload Photo Rencana..</label>
                            </div>
                          </div>
                        <?php endif ?>
                      <?php endif ?>
                        </div>
                        
                      <!-- <div class="row">
                        <div class="col-md-6">
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" readonly="" />
                            <input type="file" name="ktp" multiple="" />
                            <label class="floating-label">KTP Penanggung Jawab..</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group form-material floating" data-plugin="formMaterial">
                            <input type="text" class="form-control" readonly="" />
                            <input type="file" name="rencana" multiple="" />
                            <label class="floating-label">Rencana Gudang..</label>
                          </div>
                        </div>
                      </div> -->
                      <button type="button" id="btnSave" onclick="save()" class="btn btn-primary" style="float: right;">Update</button>
                      <!-- <a class="btn btn-block btn-default profile-readMore" href="javascript:void(0)"
                      role="button">Update</a> -->
                    </form>
                  </div>

                  <div class="tab-pane animation-slide-left" id="profile" role="tabpanel">
                    <form autocomplete="off" id="formakun">
                      <?php if($this->session->userdata('type') == 'gudang'): ?>
                        <input type="hidden" name="id" value="<?php echo $profils -> id_gudang ?>">
                      <?php else: ?>
                        <input type="hidden" name="id" value="<?php echo $profils -> id_bengkel ?>">
                      <?php endif ?>

                      <div class="form-group form-material floating" data-plugin="formMaterial">
                        <input type="text" class="form-control" name="pj" value="<?php echo $profils -> pj ?>" data-hint="Masukan Nama Penanggung Jawab."/>
                        <label class="floating-label">Nama</label>
                      </div>
                      <div class="form-group form-material floating" data-plugin="formMaterial">
                        <input type="email" class="form-control" name="email" value="<?php echo $profils -> email ?>" data-hint="Masukkan dengan e-mail ini."/>
                        <label class="floating-label">Email</label>
                      </div>
                      <div class="form-group form-material floating" data-plugin="formMaterial">
                        <label class="form-control-label" for="inputPassword2">Password</label>
                        <input type="password" class="form-control" value="<?php echo $profils -> password ?>" name="password" data-plugin="strength" data-show-toggle="true" value="" />
                        <br><br>
                      </div>
                      <button type="button"id="btnSaveakun" onclick="saveakun()" class="btn btn-primary" style="float: right;">Update</button>
                      <!-- <a class="btn btn-block btn-default profile-readMore" href="javascript:void(0)"
                      role="button">Update</a> -->
                    </form>
                  </div>

                </div>
              </div>
            </div>
            <!-- End Panel -->
          <!-- </div> -->
        <!-- </div> -->
      </div>


<script type="text/javascript">

var save_method; //for save method string
var table;
var base_url = '<?php echo base_url();?>';


function save()
{
    url = "<?php echo site_url('profil/update_usaha')?>";

    // ajax adding data to database

    var formData = new FormData($('#form')[0]);
    $.ajax({
        url : url,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {
                $('#exampleNiftyFadeScale').modal('hide');
                // reload_table();
                location.reload();
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                }
            }
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 

        }
    });
}

function saveakun()
{
    url = "<?php echo site_url('profil/update_akun')?>";

    // ajax adding data to database

    var formData = new FormData($('#formakun')[0]);
    $.ajax({
        url : url,
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {
                $('#exampleNiftyFadeScale').modal('hide');
                // reload_table();
                location.reload();
            }
            else
            {
                for (var i = 0; i < data.inputerror.length; i++) 
                {
                    $('[name="'+data.inputerror[i]+'"]').parent().parent().addClass('has-error'); //select parent twice to select div form-group class and add has-error class
                    $('[name="'+data.inputerror[i]+'"]').next().text(data.error_string[i]); //select span help-block class set text error string
                }
            }
            $('#btnSaveakun').text('save'); //change button text
            $('#btnSaveakun').attr('disabled',false); //set button enable 


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSaveakun').text('save'); //change button text
            $('#btnSaveakun').attr('disabled',false); //set button enable 

        }
    });
}
</script>